-- MIKU RABBIT HOLE SKY - iPad/Delta censored sky V1
-- Upload this Lua plus the six MIKU_RABBIT_*.tex files to the same GitHub repo.

local REPO = "https://raw.githubusercontent.com/lyn4x-js/Textures/main/"
local env = (getgenv and getgenv()) or _G
local write = rawget(env,"writefile") or writefile
local custom = rawget(env,"getcustomasset") or getcustomasset or getsynasset
if not (write and custom) then
    warn("[MIKU SKY] writefile/getcustomasset unavailable")
    return
end

local urls = {
    bk = REPO.."MIKU_RABBIT_bk.tex",
    dn = REPO.."MIKU_RABBIT_dn.tex",
    ft = REPO.."MIKU_RABBIT_ft.tex",
    lf = REPO.."MIKU_RABBIT_lf.tex",
    rt = REPO.."MIKU_RABBIT_rt.tex",
    up = REPO.."MIKU_RABBIT_up.tex",
}

local props = {
    bk="SkyboxBk", dn="SkyboxDn", ft="SkyboxFt",
    lf="SkyboxLf", rt="SkyboxRt", up="SkyboxUp"
}

local assets = {}
for face,url in pairs(urls) do
    local ok,res = pcall(function()
        local body = game:HttpGet(url)
        if type(body)~="string" or #body<4 then error("bad download") end
        local fn = "miku_rabbit_"..face..".tex"
        write(fn,body)
        return custom(fn)
    end)
    if ok then
        assets[face] = res
    else
        warn("[MIKU SKY] "..face.." failed: "..tostring(res))
    end
    task.wait(.12)
end

local Lighting = game:GetService("Lighting")

local function applySky()
    local sky = Lighting:FindFirstChildOfClass("Sky")
    if not sky then
        sky = Instance.new("Sky")
        sky.Name = "MikuRabbitSky"
        sky.Parent = Lighting
    end
    for face,asset in pairs(assets) do
        local prop = props[face]
        if prop and asset then
            pcall(function() sky[prop] = asset end)
        end
    end
end

applySky()

Lighting.ChildAdded:Connect(function(obj)
    if obj:IsA("Sky") then
        task.delay(.2, applySky)
    end
end)

task.spawn(function()
    for _,t in ipairs({0.5,1.5,3,6,10}) do
        task.wait(t)
        applySky()
    end
end)

pcall(function()
    game:GetService("StarterGui"):SetCore("SendNotification",{
        Title="Miku Rabbit Sky",
        Text="Six-face sky loaded",
        Duration=6
    })
end)
